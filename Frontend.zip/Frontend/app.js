document.addEventListener("DOMContentLoaded", function () {

/* Mobile navigation */

const menuButton = document.querySelector(".mobile-menu"); const nav = document.querySelector(".nav");

if (menuButton && nav) { menuButton.addEventListener("click", function () { nav.classList.toggle("show"); }); }

document.querySelectorAll(".nav a").forEach(function (link) { link.addEventListener("click", function () { if (nav) { nav.classList.remove("show"); } }); });

/* Login */

const loginForm = document.getElementById("loginForm");

if (loginForm) {

loginForm.addEventListener("submit", function (event) {

event.preventDefault();

const name = document.getElementById("name")?.value.trim();

const email = document.getElementById("email")?.value.trim();

const password = document.getElementById("password")?.value.trim();

if (!name || !email || !password) { showToast( "Missing information", "Please complete all fields." ); return; }

localStorage.setItem( "fitlifeLoggedIn", "true" );

localStorage.setItem( "fitlifeName", name );

localStorage.setItem( "fitlifeEmail", email );

showToast( "Login successful", "Welcome to FitLife, " + name + "." );

setTimeout(function () { window.location.href = "dashboard.html"; }, 900);

}); }

/* User name */

const userName = localStorage.getItem("fitlifeName");

document.querySelectorAll("[data-user-name]") .forEach(function (element) {

element.textContent = userName || "FitLife User";

});

/* Login status */

document.querySelectorAll("[data-login-only]") .forEach(function (element) {

if ( localStorage.getItem("fitlifeLoggedIn") !== "true" ) { element.style.display = "none"; }

});

/* Logout */

document.querySelectorAll("[data-logout]") .forEach(function (button) {

button.addEventListener("click", function () {

localStorage.removeItem("fitlifeLoggedIn"); localStorage.removeItem("fitlifeName"); localStorage.removeItem("fitlifeEmail");

showToast( "Logged out", "You have been logged out of FitLife." );

setTimeout(function () { window.location.href = "index.html"; }, 700);

});

});

/* Notifications */

const notificationCount = document.getElementById("notificationCount");

const notificationButton = document.getElementById("notificationButton");

if (notificationButton) {

notificationButton.addEventListener( "click", function () {

window.location.href = "notifications.html";

} );

}

const unread = localStorage.getItem("fitlifeUnread");

if ( notificationCount && unread === "0" ) { notificationCount.style.display = "none"; }

/* Login welcome message */

if ( localStorage.getItem("fitlifeLoggedIn") === "true" && sessionStorage.getItem("fitlifeWelcomeShown") !== "true" ) {

sessionStorage.setItem( "fitlifeWelcomeShown", "true" );

const name = localStorage.getItem("fitlifeName") || "FitLife User";

setTimeout(function () {

showToast( "Welcome back", "Good to see you again, " + name + "." );

}, 700);

}

/* Plan buttons */

document.querySelectorAll("[data-plan-link]") .forEach(function (button) {

button.addEventListener("click", function () {

const type = button.dataset.planLink;

if (type === "workout") { window.location.href = "workouts.html"; }

if (type === "diet") { window.location.href = "diet.html"; }

});

});

});

/* Toast */

function showToast(title, message) {

let container = document.querySelector(".toast-container");

if (!container) {

container = document.createElement("div");

container.className = "toast-container";

document.body.appendChild(container); }

const toast = document.createElement("div");

toast.className = "toast";

toast.innerHTML = <strong>${title}</strong> <p>${message}</p> ;

container.appendChild(toast);

setTimeout(function () {

toast.style.opacity = "0";

setTimeout(function () { toast.remove(); }, 300);

}, 3500); }

/* Mark notifications as read */

function markNotificationsRead() {

localStorage.setItem( "fitlifeUnread", "0" );

const count = document.getElementById("notificationCount");

if (count) { count.style.display = "none"; }

showToast( "Notifications cleared", "You are all caught up." ); }

/* Diet plan */

function selectDietPlan(plan) {

localStorage.setItem( "fitlifeDietPlan", plan );

showToast( "Diet plan selected", plan + " has been selected for your profile." );

}

/* Workout plan */

function selectWorkoutPlan(plan) {

localStorage.setItem( "fitlifeWorkoutPlan", plan );

showToast( "Workout plan selected", plan + " has been selected for your profile." );

}